package app.tukorea.client_application.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import app.tukorea.client_application.R
import app.tukorea.client_application.databinding.FragmentDetailBinding
import kotlinx.android.synthetic.main.fragment_detail.*


class DetailFragment : Fragment() {

        lateinit var binding: FragmentDetailBinding
        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {

            binding=FragmentDetailBinding.inflate(inflater, container, false)


            //수량 조정
            val output=binding.textQuantity
            val upbtn=binding.btnUp
            val downbtn=binding.btnDown
            var number=0

            upbtn.setOnClickListener{
                number++
                output.setText(number.toString())
            }

            downbtn.setOnClickListener{
                number--
                output.setText(number.toString())
            }


            return binding.root


        }



}