package app.tukorea.client_application

import android.graphics.Rect
import android.hardware.camera2.CameraManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ScrollView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentTransaction
import app.tukorea.client_application.databinding.ActivityMainBinding
import app.tukorea.client_application.fragment.DetailFragment
import com.google.android.material.tabs.TabLayout
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        fun ScrollView.scrollToView(view: View) {
            val y = computeDistanceToView(view)
            this.smoothScrollTo(0, y)
        }

        binding.menuTab.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when(tab?.position) {
                    0 -> {
                        binding.scrollView.scrollToView(binding.noodleBlackLayout)
                    }

                    1 -> {
                        binding.scrollView.scrollToView(binding.riceFriedLayout)
                    }

                    2 -> {
                        binding.scrollView.scrollToView(binding.dishPigLayout)
                    }

                }

            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {

            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }
        })
//        binding.noodleBlackLayout.setOnClickListener(Layoutlistener())
//        binding.noodleRedLayout.setOnClickListener(Layoutlistener2())
//        binding.riceFriedLayout.setOnClickListener(Layoutlistener3())
//        binding.dishPigLayout.setOnClickListener(Layoutlistener4())

        binding.bagButton.setOnClickListener {  }

        //상품 옵션 프래그먼트 호출부
        val view=binding.root
        setContentView(view)

        fun setFragment(){
            val transaction=supportFragmentManager.beginTransaction().add(R.id.noodle_black_layout, DetailFragment())
            transaction.commit()
        }

        binding.noodleBlackImg.setOnClickListener{
            setFragment()
        }

    }

    internal fun ScrollView.computeDistanceToView(view: View): Int {
        return abs(calculateRectOnScreen(this).top - (this.scrollY + calculateRectOnScreen(view).top))
    }

    internal fun calculateRectOnScreen(view: View): Rect {
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        return Rect(
            location[0],
            location[1],
            location[0] + view.measuredWidth,
            location[1] + view.measuredHeight
        )
    }

//    inner class Layoutlistener: View.OnClickListener{
//        override fun onClick(p0: View?) {
//            TODO("Not yet implemented")
//        }
//    }
//
//    inner class Layoutlistener2: View.OnClickListener{
//        override fun onClick(p0: View?) {
//            TODO("Not yet implemented")
//        }
//    }
//
//    inner class Layoutlistener3: View.OnClickListener{
//        override fun onClick(p0: View?) {
//            TODO("Not yet implemented")
//        }
//    }
//
//    inner class Layoutlistener4: View.OnClickListener{
//        override fun onClick(p0: View?) {
//            TODO("Not yet implemented")
//        }
//    }

}
